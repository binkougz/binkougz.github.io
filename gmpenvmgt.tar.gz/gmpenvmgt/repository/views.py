from django.shortcuts import render

# Create your views here.
def home(request):
    greetwords = "Welcome to the Repository."
    context = {
        "greetings": greetwords,
    }
    return render(request, 'home.html', context)