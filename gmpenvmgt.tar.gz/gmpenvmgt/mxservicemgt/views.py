from django.shortcuts import render

# Create your views here.
def home(request):
    greetwords = "Welcome to the MX Services page."
    context = {
        "greetings": greetwords,
    }
    return render(request, 'home.html', context)