from django.conf.urls import patterns, url
from passwdmgt import views

urlpatterns = patterns('',
        url(r'^$', views.home, name='home'))