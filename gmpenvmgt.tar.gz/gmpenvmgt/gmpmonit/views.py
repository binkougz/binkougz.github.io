# -*- coding: utf-8 -*-
from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def home(request):
    greetwords = "Welcome to the blog raw page."
    context = {
        "greetings": greetwords,
    }
    return render(request, 'base.html', context)
