from django.contrib import admin

# Register your models here.

from .models import *

class ServerAdmin(admin.ModelAdmin):
    list_display = ('hostname', 'model', 'uptime')

admin.site.register(MXEnv)
admin.site.register(Connection)
admin.site.register(UnixServer, ServerAdmin)
admin.site.register(UnixUser)
admin.site.register(Service)
admin.site.register(Statistic)
