from django.db import models

# Create your models here.

class MXEnv(models.Model):
    """
    Define Murex Enviroments.
    """
    name  = models.CharField('envname', max_length=100)
    fileserver  = models.ForeignKey('UnixServer')
    port  = models.CharField('port', max_length=100)
    mxnetport  = models.CharField('mxnetport', max_length=100)
    site  = models.CharField('site', max_length=100)

    def __str__(self):
        return self.name

class Connection(models.Model):
    """
    Define the connections between Env and Servers.
    """
    env = models.ForeignKey(MXEnv)
    server = models.ForeignKey('UnixServer')
    path = models.CharField('path', max_length=256)
    status = models.CharField('status', max_length=100)

    def __str__(self):
        return "%s @ %s" % (self.env, self.server)

class UnixServer(models.Model):
    """
    Define Unix Server.
    """
    hostname = models.CharField('hostname', max_length=256)
    model = models.CharField('model', max_length=100)
    uptime = models.CharField('uptime', max_length=100)

    def __str__(self):
        return self.hostname

class UnixUser(models.Model):
    """
    Define Unix User details.
    """
    userid   = models.CharField('userid',   max_length=256) 
    password = models.CharField('password', max_length=256) 
    ppkfile  = models.CharField('ppk',      max_length=256)
    status   = models.CharField('status',   max_length=50)
    expirydate  = models.DateTimeField('expirydate', null=True, editable=True)
    updatetime = models.DateTimeField(auto_now=True)
    server   = models.ForeignKey(UnixServer)

    def __str__(self):
        return self.userid


class Service(models.Model):
    """
    Define MX Services.
    """
    connection  = models.ForeignKey(Connection)
    name = models.CharField('name', max_length=256)
    mxres = models.CharField('mxres', max_length=512)
    uptime = models.CharField('uptime', max_length=512)
    status = models.CharField('status', max_length=256)
    script = models.CharField('script', max_length=100)
    layer = models.CharField('srvlayer', max_length=100)
     
    def __str__(self):
        return self.name

class Statistic(models.Model):
    """
    Define Server statistic data.
    """
    server = models.ForeignKey(UnixServer)
    sampletime = models.DateTimeField()
    cpuusage = models.CharField('cpuusage', max_length=100)
    memusage = models.CharField('memusage', max_length=100)
    diskusage = models.CharField('diskusage', max_length=1024)

    def __str__(self):
        return "%s %s" % (self.server, str(self.sampletime))
